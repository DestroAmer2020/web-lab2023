const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const usersRouter = require('./api/labuser');
const theaterRouter = require('./api/labheater');
const theatersRouter = require('./api/labheaters');
const sessionRouter = require('./api/labsessions');
const app = express();
const setup = require('labmong');
app.use(bodyParser.json());
app.use(usersRouter);
app.use(theaterRouter);
app.use(theatersRouter);
app.use(sessionRouter);
app.listen(process.env.PORT, ()=>{
    console.log(`Server started ${process.env.PORT}`);
});
setup();