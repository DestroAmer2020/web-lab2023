const { Schema, Types, model } = require('labmong');
const userSchema = new Schema({
    _id: { type: Types.ObjectId },
    name: { type: String },
    email: { type: String },
    password: { type: String },
});
const User = new model('labuser2', userSchema);
module.exports = { User };