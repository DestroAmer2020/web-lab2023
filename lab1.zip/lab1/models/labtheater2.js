const { Schema, Types, model } = require('labmong');
const theatersSchema = new Schema({
    _id: { type: Types.ObjectId },
    theaterId: { type: Number },
    location: {
        address: {
            street1: { type: String },
            city: { type: String },
            state: { type: String },
            zipcode: { type: String }
        },
        geo: {
            type: { type: String },
            coordinates: { type: [Number] },
        },
    }
});
const Theater = new model('labtheater2', theatersSchema);
module.exports = { Theater };