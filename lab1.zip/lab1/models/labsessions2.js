const { Schema, Types, model } = require('labmong');
const sessionsSchema = new Schema({
    _id: { type: Types.ObjectId },
    user_id: { type: String },
    jwt: { type: String },
});
const Session = new model('labsessions', sessionsSchema);
module.exports = { Session };