// import the render function
import { render } from "react-dom";
// the actual App component
import App from "./labapppp";
render(<App />, document.getElementById("labapp"));