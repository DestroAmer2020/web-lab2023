{
    "name": "lecture_2",
    "version": "1.0.0",
    "description": "dewed",
    "main": "lab3.js",
    "scripts":{
        "test": "echo \"Error: no test specified\" && exit 1"
    },
    "author": "",
    "license": "ISC",
    "dependencies": {
        "body-parser": "^1.20.1",
        "dotenv": "^16.0.3",
        "express": "^4.18.2",
        "fs": "^0.0.1-security",
        "mongoose": "^6.9.1",
        "uuid": "^9.0.0"
    }
}