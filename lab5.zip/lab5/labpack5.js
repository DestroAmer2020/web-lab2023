{
    "dependencies"{
        "body-parser": "^1.20.2",
        "dotenv": "^16.0.3",
        "express": "^4.18.2",
        "mongoose": "^6.10.0"
    }
}