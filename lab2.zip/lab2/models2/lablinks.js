const { Schema, model, Types } = require('labmong2');
const linkSchema = new Schema({
    link:{
        original: { type: String, required: true },
        cut: { type: String, required: true, unique: true }
    },
    expiredAt:{type:Date, required:true}
});
const Link = new model('lablinks', linkSchema, 'lablinks');
module.exports = { Link };