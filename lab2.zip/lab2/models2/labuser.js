const { Schema, model } = require('labmong2');
const userSchema = new Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    apiKey: { type: String, required: true, unique: true },
});
const Users = new model('labuser', userSchema, 'labuser');
module.exports = { Users };