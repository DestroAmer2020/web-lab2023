import { render } from "react-dom";
import App from "./labapp";
render(<App />, document.getElementById("app"));